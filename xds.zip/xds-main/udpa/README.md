# THESE PROTOS ARE DEPRECATED

We are no longer using the "UDPA" name, and we are moving away from the
protos in this tree.  Users should prefer the corresponding protos in
the xds tree instead.

No new changes will be accepted for protos in this tree.  If you want to
change something, make the change to the corresponding proto in the xds
tree instead, and then change your protos to use the xds proto instead
of the udpa proto.
